const express = require("express");
const bodyParser = require("body-parser");
const db = require("./database"); // Importar la base de datos

const app = express();
const port = 3000;

// Configurar middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Ruta para el formulario principal
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

// Ruta para guardar los datos de la maquinaria
app.post("/guardar", (req, res) => {
  const { nombre, modelo, estado, tipo } = req.body;

  db.insertMaquinaria(nombre, modelo, estado, tipo)
    .then(() => {
      res.send("Datos guardados correctamente.");
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send("Error al guardar los datos.");
    });
});

// Ruta para mostrar las máquinas registradas
app.get("/maquinas", (req, res) => {
  db.getMaquinaria()
    .then((maquinas) => {
      let maquinasHTML = "<h1>Maquinarias Registradas</h1><ul>";
      maquinas.forEach((maquina) => {
        maquinasHTML += `<li>${maquina.nombre} - ${maquina.modelo} - ${maquina.estado} - ${maquina.tipo}</li>`;
      });
      maquinasHTML += "</ul>";
      res.send(maquinasHTML);
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send("Error al obtener las máquinas registradas.");
    });
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor ejecutándose en http://localhost:${port}`);
});

app.get('/borrar', (req, res) => {
    db.run('DELETE FROM maquinas', function(err) {
      if (err) {
        console.error("Error al borrar las máquinas:", err.message);
        res.status(500).send("Error al borrar las máquinas.");
        return;
      }
      console.log('Todas las máquinas han sido eliminadas.');
      res.send('Todas las máquinas han sido eliminadas.');
    });
  });