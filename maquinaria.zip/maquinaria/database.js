const sqlite3 = require("sqlite3").verbose();

// Crear o abrir la base de datos
const db = new sqlite3.Database("./maquinaria.db", (err) => {
  if (err) {
    return console.error("Error al conectar con la base de datos: ", err.message);
  }
  console.log("Conexión con la base de datos establecida.");
});

// Crear la tabla si no existe
db.run(
  `CREATE TABLE IF NOT EXISTS maquinaria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    modelo TEXT NOT NULL,
    estado TEXT NOT NULL,
    tipo TEXT NOT NULL
  )`
);

// Función para insertar maquinaria en la base de datos
function insertMaquinaria(nombre, modelo, estado, tipo) {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO maquinaria (nombre, modelo, estado, tipo) VALUES (?, ?, ?, ?)`;
    db.run(sql, [nombre, modelo, estado, tipo], function (err) {
      if (err) {
        return reject(err);
      }
      resolve(this.lastID);
    });
  });
}

// Función para obtener todas las máquinas registradas
function getMaquinaria() {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM maquinaria";
    db.all(sql, [], (err, rows) => {
      if (err) {
        return reject(err);
      }
      resolve(rows);
    });
  });
}

module.exports = {
  insertMaquinaria,
  getMaquinaria,
};
